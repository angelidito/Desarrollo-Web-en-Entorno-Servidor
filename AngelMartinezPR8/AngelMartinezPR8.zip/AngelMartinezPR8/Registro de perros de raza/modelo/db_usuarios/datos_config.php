<?php

const BD_HOST = 'localhost:3307';
const BD_USER = 'root';
const BD_PW = '';
const BD_NAME = 'perro_raza_usuarios';
const BD_CHARSET = "UTF8";